<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Http\Requests\Utilisateur\ConnexionRequete;

class UtilisateurController extends Controller
{
    public function s_inscrire(Request $requete){

        $requete->validate([
            'prenom' => ['required', 'string', 'max:255'],
            'nom' => ['required', 'string', 'max:255'],
            'pseudo' => ['required', 'string', 'max:255',  'unique:users'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'tel' => ['required', 'regex:/(0)[0-9]{9}/', 'unique:users'],
            'mot_de_passe' => ['required', 'confirmed', Rules\Password::defaults()],
            'adresse' => ['required', 'string', 'max:255']
        ]); 
        
        $utilisateur = User::create([
            'prenom' => $requete->prenom,
            'nom' => $requete->nom,
            'pseudo' => $requete->pseudo,
            'email' => $requete->email,
            'tel' => $requete->tel,
            'adresse' => $requete->adresse,
            'password' => Hash::make($requete->mot_de_passe)
        ]);

        Auth::login($utilisateur);

        return redirect()->route('acceuil');
    }

    public function se_connecter(ConnexionRequete $requete){
        $requete->authenticate();
        $requete->session()->regenerate();
        
        return redirect()->route('acceuil');
    }

    public function sortir(Request $requete)
    {
        Auth::guard('web')->logout();

        $requete->session()->invalidate();
        $requete->session()->regenerateToken();

        return redirect()->route('se-connecter');
    }
}
