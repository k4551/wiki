<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Requests\Utilisateur\ConnexionRequete;

class AdminController extends Controller
{
    public function se_connecter(ConnexionRequete $requete){
        $requete->authenticate();
        $requete->session()->regenerate();
        return redirect()->route('gerer-paneau');
    }
    public function gerer(){
        return view('admin.paneau');
    }
}
