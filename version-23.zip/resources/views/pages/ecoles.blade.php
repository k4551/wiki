<x-layout.layout :titre="'Ecoles'">
    <header class="container">
        <section  class="nav-scroller py-1 mb-2">
            <nav class="nav d-flex justify-content-start">
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">CS2i</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">EPITECH</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">ESIN</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">Ecole 42</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">ENI</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">ESCEN</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">HETIC</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">IIM</a>
              <a class="badge bg-dark rounded-pill text-light text-decoration-none px-3 py-2 m-2" href="#">L'ESD</a>
            </nav>
        </section>
    </header>
    <!-- section introduction -->
    <section class="container col-xxl-8 px-4 py-5">
        <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
            <div class="col-10 col-sm-8 col-lg-6">
                <img src="{{ asset('img/logo.png')}}" class="d-block mx-lg-auto img-fluid" alt="digital wiki" width="400" height="600" loading="lazy">
            </div>
            <div class="col-lg-6">
                <h1 class="display-5 fw-bold lh-1 mb-3">Les écoles d'informatique et du degital</h1>
                <p class="lead">
                    L'encyclopédie crée par des étudiants d'école informatiques
                </p>
                <div class="d-grid gap-2 d-md-flex justify-content-md-start">
                    <button type="button" class="btn btn-secondary btn-lg px-4 me-md-2">découvrez plus ...</button>
                </div>
            </div>
        </div>
    </section>


    <!-- Posts -->
    <section class="row mb-2">
        @foreach ($posts as $post)
            <x-post :post="$post"></x-post> 
        @endforeach
    </section>


</x-layout.layout>