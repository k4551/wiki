<x-layout.layout :titre="'Qui sommes-nous ?'" :annonce="false">
    <section class="container bg-dark text-secondary px-4 my-5 text-center">
        <div class="py-5">
          <h1 class="display-5 fw-bold text-white">Qui sommes-nous ?</h1>
          <div class="col-lg-6 mx-auto">
            <p class="fs-5 mb-4">
                Nous vous souhaitons, une bonne navigation sur DIGITAL WIKI, et espèrons que vous serez séduit par le site en lui-même, 
                et que le contenu vous passionnera, autant que nous avons tous eu plaisir de participer à cette aventure enrichissante.
                Retrouvez nous sur:
            </p>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                <button type="button" class="btn btn-outline-light btn-lg px-4">facebook</button>
                <button type="button" class="btn btn-outline-light btn-lg px-4">twitter</button>
                <button type="button" class="btn btn-outline-light btn-lg px-4">instagram</button>
            </div>
          </div>
        </div>
    </section>
    <section class="container">

        <hr class="featurette-divider">
        <div class="row featurette">
            <div class="col-md-7 d-flex flex-column justify-content-center">
                <h2 class="featurette-heading">Pierre ZIMBRIS</h2>
                <p class="lead">
                    Professeur référant de notre école numérique et notre tuteur de Stage, expert en communication depuis 2015.
                    Il était également commerçant (dans des magasins de prêt à porter, de téléphonie mobile et magasin discount), responsable communication 
                    et co-fondateur de la 1ère galerie commerciale sur Internet de regroupement de commerçants. 
                    La particularité était la création de vitrine Internet par secteur en positionnant chaque adhérent en première page de réponse de Google.
                </p>
            </div>
            <div class="col-md-5">
                <img src="{{ asset('img/charge.jpg')}}" class="img-fluid mx-auto" 
                width="500" height="500" role="img">
            </div>
        </div>

        <hr class="featurette-divider">
        <div class="row featurette">
            <div class="col-md-5">
                <img src="{{ asset('img/reseau.jpg')}}" class="img-fluid mx-auto" 
                width="500" height="500" role="img">
            </div>
            <div class="col-md-7 d-flex flex-column justify-content-center">
                <h2 class="featurette-heading">Sarah KOUIDER AKIL</h2>
                <p class="lead">
                    Etudiante en 2éme année de DUT informatique à l'École numérique Université Paris-Saclay. 
                    Passionnée par les nouvelles technologies informatiques, et le monde du numérique en général, 
                    ce blog est réalisé en langage Profitant d'un stage en entreprise pour valider
                    sa fin d'étude afin d'obtenir le diplôme ...  ,
                    Si le temps me le permet je continuerais à faire vivre ce Blog, dans le cas contraire,
                    je passerais la main à d'autres étudiants pour qu'ils puissent à leur tour profiter de 
                    cette expérience pour enrichir leurs connaissances en programmation informatique. 
                </p>
            </div>
        </div>


        <hr class="featurette-divider">
        <div class="row featurette">
            <div class="col-md-7 d-flex flex-column justify-content-center">
                <h2 class="featurette-heading">Notre but</h2>
                <p class="lead">
                    Nous vous souhaitons, une bonne navigation sur Digital Wiki,
                    et espèrons que vous serez séduit par le Site en lui-même, 
                    et que le contenu vous passionnera, autant que nous avons tous
                    eu plaisir de participer à cette aventure enrichissante.
                    Retrouvez nous sur : Facebook, Twitter et Instagram.
                </p>
            </div>
            <div class="col-md-5">
                <img src="{{ asset('img/digital.jpg')}}" class="img-fluid mx-auto" 
                width="500" height="500" role="img">
            </div>
        </div>

    </section>

</x-layout.layout>