<x-layout.layout :titre="'Acceuil'" :annonce="false">
    <!-- section introduction -->
    <section class="container col-xxl-8 px-4 py-5">
        <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
            <div class="col-10 col-sm-8 col-lg-6">
                <img src="{{ asset('img/logo.png')}}" class="d-block mx-lg-auto img-fluid" alt="digital wiki" width="400" height="600" loading="lazy">
            </div>
            <div class="col-lg-6">
                <h1 class="display-5 fw-bold lh-1 mb-3">L'encyclopédie du digital</h1>
                <p class="lead">
                    L'encyclopédie crée par des étudiants d'école informatiques
                </p>
                <div class="d-grid gap-2 d-md-flex justify-content-md-start">
                    <button type="button" class="btn btn-secondary btn-lg px-4 me-md-2">découvrez plus ...</button>
                </div>
            </div>
        </div>
    </section>

    <section class="container espace">

        <div class="row">

            <div class="col-lg-4">
                <img src="{{asset('img/logo.png')}}" class="rounded-circle" width="140" height="140">
        
                <h2 class="display-6">Métiers</h2>
                <p class="lead">Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
                <p><a class="btn btn-secondary" href="#">Voir plus &ThickSpace; &rarr;</a></p>
            </div>

            <div class="col-lg-4">
                <img src="{{asset('img/logo.png')}}" class="rounded-circle" width="140" height="140">
        
                <h2 class="display-6">Entrepreneurs</h2>
                <p class="lead">Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
                <p><a class="btn btn-secondary" href="#">Voir plus &ThickSpace; &rarr;</a></p>
            </div>

            <div class="col-lg-4">
                <img src="{{asset('img/logo.png')}}" class="rounded-circle" width="140" height="140">
        
                <h2 class="display-6">Ecoles</h2>
                <p class="lead">Some representative placeholder content for the three columns of text below the carousel. This is the first column.</p>
                <p><a class="btn btn-secondary" href="#">Voir plus &ThickSpace; &rarr;</a></p>
            </div>


        </div>
    </section>
</x-layout.layout>