<x-layout.layout :titre="Auth::user()->pseudo" :annonce="false">
    <section class="container py-5">
        <div class="row">
            <!-- Les info d'utilisateur -->
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                      <h5 class="card-title">{{ Auth::user()->pseudo  }}</h5>
                      <p class="card-text">{{ Auth::user()->prenom ." ". Auth::user()->nom}} </p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">{{ Auth::user()->tel }}</li>
                        <li class="list-group-item">{{ Auth::user()->email }}</li>
                        <li class="list-group-item">{{ Auth::user()->adresse }}</li>
                    </ul>
                    <div class="card-body">
                      <a href="" class="card-link text-decoration-none">Modifier</a>
                    </div>
                </div>
            </div>

            <!-- Les posts publié par l'utilisateur -->
            <div class="col-8">
                <div class="m-2">
                    <a href="{{ route('posts.publier')}}" class="btn btn-primary">Publier nouveau post</a>
                </div>
                <div class="row p-2">
                    @foreach (Auth::user()->posts()->get() as $post)
                        <x-post :post="$post"></x-post>
                    @endforeach
                </div>
            </div>

            
        </div>
    </section>
</x-layout.layout>