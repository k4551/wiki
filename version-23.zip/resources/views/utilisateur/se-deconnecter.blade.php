<x-layout.layout :titre="'Se déconnecter'" :gradient="true" :reduit="true" :annonce="false">

</x-layout.layout>