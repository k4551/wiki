<x-layout.layout :titre="'S\'inscrire'">

    <section class="container-fluid py-5" style="background: linear-gradient(to right, blue, pink);">
        <div class="row d-flex justify-content-center">
            <div class="col-1 d-flex justify-content-center flex-lg-column">
                <a href="" class="btn btn-outlined my-1" style=" color: #FED1CC"><i class="fs-2 fab fa-facebook-square"></i></a>
                <a href="" class="btn btn-outlined my-1" style=" color: #FED1CC"><i class="fs-2 fab fa-google-plus-square"></i></a>
                <a href="" class="btn btn-outlined my-1" style=" color: #FED1CC"><i class="fs-2 fab fa-twitter-square"></i></a>
            </div>
            <div class="col-12 col-lg-5">
                <div class="card text-white" style="background: rgba(0,0,0,0.5)">


                    <!-- L'entete de la carte -->
                    <div class="card-header text-center">
                        <h3 class="h3">S'inscrire</h3>
                    </div>

                    <!-- Le corps de la carte -->
                    <div class="card-body">
                        <!-- marge pour affincher des erreurs du validation -->
                        @if ($errors->any())
                            <div class="alert alert-danger" role="alert">
        
                                @foreach ($errors->all() as $error)
                                    <div>{{$error}}</div>
                                @endforeach
                            </div>
                        @endif
        
                        <!-- Form pour se connecter -->
                        <form action="{{ route('nouveau-utilisateur')}}" method="post">
                            @csrf
                            @method('post')
                            <div class="input-group form-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-user"></i></div>
                                <input type="text" name="prenom"  value="{{ old('prenom') }}" class="form-control" placeholder="Prénom">
                            </div>
                            <div class="input-group form-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-user"></i></div>
                                <input type="text" name="nom"  value="{{ old('nom') }}" class="form-control" placeholder="Nom">
                            </div>
                            <div class="input-group form-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-user"></i></div>
                                <input type="text" name="pseudo"  value="{{ old('pseudo') }}" class="form-control" placeholder="Pseudo">
                            </div>
                            <div class="input-group form-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-phone"></i></div>
                                <input type="tel" name="tel"  value="{{ old('tel') }}" class="form-control" placeholder="0 6 123 345 678">
                            </div>
                            <div class="input-group form-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-envelope"></i></div>
                                <input type="email" name="email"  value="{{ old('email') }}" class="form-control" placeholder="example@mail.com">
                            </div>
                            <div class="input-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-key"></i></div>
                                <input type="password" name="password" class="form-control" placeholder="Mot de passe">
                            </div>
                            <div class="input-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-key"></i></div>
                                <input type="password" name="password_confirmation" class="form-control" placeholder="Mot de passe">
                            </div>
                            <div class="input-group form-group my-2">
                                <div class="input-group-text bg-primary"><i class="fas fa-location"></i></div>
                                <input type="text" name="adresse"  value="{{ old('adresse') }}" class="form-control" placeholder="Adresse">
                            </div>
                            <div class="form-group float-end">
                                <button type="submit" class="btn btn-primary">S'inscrire</button>
                            </div>
                        </form>
                    </div>

                    <!-- Le pied de la carte -->
                    <div class="card-footer">
                        <p class="lead text-center">
                            Vous êtes déja inscrit ?
                        </p>
                        <div class="d-flex justify-content-center">
                            <a class="btn btn-link text-decoration-none mx-3 p-2" href="{{route('se-connecter')}}">Se connecter</a>
                            <span class="lead p-1">ou</span>
                            <a class="btn btn-link text-decoration-none mx-3 p-2" href="">Mot de passe oublié</a>
                        </div>
                    </div>


                </div>
            </div>
        </div>

    </section>
</x-layout.layout>