<x-layout.layout :titre="'Admin'" :annonce="false" :reduit="true">
    <section class="container">
        <div class="row py-5 d-flex justify-content-center">
            <div class="col-sm-4 col-md-6 py-5">

                <img class="d-block mx-auto my-4" src="{{ asset('img/logo.png')}}" alt="" width="72" height="72">
         
                <!-- marge pour affincher des erreurs du validation -->
                @if ($errors->any())
                    <div class="alert alert-danger" role="alert">
    
                        @foreach ($errors->all() as $error)
                            <div>{{$error}}</div>
                        @endforeach
                    </div>
                @endif
    
                <!-- Form pour se connecter -->
                <form action="{{ route('nouvelle-connexion-tant-q1-admin')}}" method="post">
                    @csrf
                    @method('post')
                    <div class="input-group form-group my-2">
                        <div class="input-group-text bg-primary"><i class="fas fa-user"></i></div>
                        <input type="text" name="pseudo"  value="{{ old('pseudo') }}" class="form-control" placeholder="Pseudo">
                    </div>
                    <div class="input-group my-2">
                        <div class="input-group-text bg-primary"><i class="fas fa-key"></i></div>
                        <input type="password" name="password" class="form-control" placeholder="Mot de passe">
                    </div>
                    <div class="form-group float-end">
                        <button type="submit" class="btn btn-primary">Se connecter</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</x-layout.layout>