<x-layout.layout :titre="'acheteur'" :annonce="false" :reduit="true">
    <section class="container py-5">
        admin paneau
    </section>
</x-layout.layout>