
<x-layout.layout :titre="'nouveau post'" :reduit="true" :annonce="false">
    <script type="text/javascript"  src='https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js' referrerpolicy="origin">
    </script>
    <script type="text/javascript">
        tinymce.init({
            selector: '#contenu',
        });
    </script>


    <section class="container py-5">
        <div class="row mt-5">
            <div class="col">
                <!-- marge pour afficher les erreurs du validation -->
                @if ($errors->any())
                    <div class="alert alert-danger" role="alert">
    
                        @foreach ($errors->all() as $error)
                            <div>{{$error}}</div>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>

        <form action="{{ route('posts.sauvegarder')}}" method="post" enctype="multipart/form-data">
            <div class="row mt-5">
                @csrf
                @method('post')
                <section class="col-md-6">
                    <div class="form-group my-3">
                        <label  class="form-label" for="titre">Titre</label>
                        <input  class="form-control" type="text" id="titre" name="titre"  value="{{ old('titre') }}" placeholder="Titre">
                    </div>
                    <div class="form-group my-3">
                        <label class="form-label" for="contenu">Contenu</label>
                        <textarea class="form-control" rows="6" id="contenu" name="contenu" placeholder="Contenu">{{ old('contenu') }}</textarea>
                    </div>

                </section>
                <section class="col-md-6  p-2">
                    <div class="mb-3">
                        <label for="illustration" class="form-label">Illustration</label>
                        <input class="form-control" type="file" accept="image/*" name="illustration" id="illustration">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="type">Type</label>
                        <select class="form-select" id="type" name="type" value="{{ old('type') }}" aria-label="selectionner le type post">
                            <option selected value="metiers">Métiers du numérique</option>
                            <option value="entrepreneurs">Entrepreneurs du numérique</option>
                            <option value="ecoles">Ecoles du numérique</option>
                        </select>
                    </div>
                    <div class="row p-2">
                        <div class="col">
                            <div class="form-check form-switch">
                                <label class="form-check-label" for="active">Active</label>
                                <input class="form-check-input" type="checkbox" id="active" name="active"  checked>
                            </div>
                        </div>
                        <div class="col">
                            <input type="submit" value="Publier" class="btn btn-primary float-end">
                        </div>
                    </div>

                </section>
            </div>
        </form>
    </section>
</x-layout.layout>