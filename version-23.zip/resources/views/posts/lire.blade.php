<x-layout.layout :titre="$post->titre" :reduit="true">
    <section class="container py-5">

        <article class="row">
            <h2 class="display-4">{{ $post->titre}}</h2>
            <p class="lead">January 1, 2021 par <a class="text-decoration-none" href="">{{ $post->user->pseudo}}</a></p>
            <img src="{{ route('posts.charger-image', [$post->id, $post->slug]) }}" alt="" class="img-fluid" loading="lazy">
            <section class="py-5">
                {!! $post->contenu !!}
            </section>
        </article>

        <article class="row">
            <div>
                <h1>Espace commentaires</h1>
                <form method="post" action="{{route('posts.commenter', [$post])}}">
                    @csrf
                    @method('post')

                    <label for="message" class="form-label">Commentaire</label>
                    <div class="input-group mb-3">
                        <textarea class="form-control" id="message" name="contenu" cols="50" rows="7"></textarea><br>
                    </div>
                    <input button type="submit" class="btn btn-secondary mb-2" value="Envoyer le commentaire">
            
                </form>
            </div>
            <div class="list-group m-2">
                @foreach ($post->commentaires as $commentaire)
                <div class="list-group-item">
                    <p class="h4">
                        {{ $commentaire->user->pseudo }}
                    </p>
                    <p class="lead py-3">{{ $commentaire->contenu }}</p>
                    <p class="fz-sm float-end">{{ $commentaire->created_at}}</p>
                </div>
                @endforeach
            </div>
        </article>

    </section>
</x-layout.layout>