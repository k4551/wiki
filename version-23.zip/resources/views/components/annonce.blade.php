
<div class="position-md-fixed" style="z-index: -1;">

    <!-- 2eme annonce -->
    <div class="card mb-4 rounded-3 shadow-sm border-primary">
        <div class="card-header py-3 text-dark text-center bg-primary border-primary">
          <h4 class="my-0 fw-normal">Votre pub ici</h4>
        </div>
        <img src="{{ asset('img/annonce.gif')}}" alt="" class="card-img-top">
        <div class="card-body text-center">
          <h1 class="card-title pricing-card-title">€29<small class="text-muted fw-light">/mois</small></h1>
          <p class="lead">
            Vous êtes entrepreneur ou startup, votre pub ici.  
          </p>
          <form action="{{route('annonces.acheter')}}" method="post">
              @csrf 
              @method('post')
              <button type="submit" class="w-100 btn btn-lg btn-primary">Acheter</button>
          </form>
        </div>
    </div>

    <!-- 1ere annonce -->
    <div class="card mb-4 rounded-3 shadow-sm border-primary">
        <div class="card-header py-3 text-dark text-center bg-primary border-primary">
          <h4 class="my-0 fw-normal">Votre pub ici</h4>
        </div>
        <img src="{{ asset('img/annonce.gif')}}" alt="" class="card-img-top">
        <div class="card-body text-center">
          <h1 class="card-title pricing-card-title">€29<small class="text-muted fw-light">/mois</small></h1>
          <p class="lead">
            Vous êtes une agence digitale, votre pub ici.
          </p>
          <button type="button" class="w-100 btn btn-lg btn-primary">Achetez</button>
        </div>
    </div>

    <!-- 3eme annonce -->
    <div class="card mb-4 rounded-3 shadow-sm border-primary">
        <div class="card-header py-3 text-dark text-center bg-primary border-primary">
          <h4 class="my-0 fw-normal">Votre pub ici</h4>
        </div>
        <img src="{{ asset('img/annonce.gif')}}" alt="" class="card-img-top">
        <div class="card-body text-center">
          <h1 class="card-title pricing-card-title">€29<small class="text-muted fw-light">/mois</small></h1>
          <p class="lead">
            Vous êtes une école numérique, votre pub ici. 
          </p>
          <button type="button" class="w-100 btn btn-lg btn-primary">Achetez</button>
        </div>
    </div>


</div>