@props(['post'])
<article class="col-12">
    <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
        <strong class="d-inline-block mb-2 text-primary">{{ $post->type }}</strong>
        <h3 class="mb-0">{{ $post->titre }}</h3>
        <div class="mb-1 text-muted">{{ $post->crerated_at }}</div>
        <p class="card-text mb-auto">
            <span class="lead">{{$post->user->pseudo}}</span>
            <span class="lead">par</span>
            <span class="lead">{{$post->created_at}}</span>
        </p>
        <a class="stretched-link text-decoration-none" href="{{ route('posts.lire', [$post->id, $post->slug]) }}">Lire &RightArrow;</a>
        </div>
        <div class="col-auto d-none d-lg-block">
        <img class="img h-100" src="{{ route('posts.charger-image', [$post->id, $post->slug]) }}"  width="200" role="img" aria-label="Placeholder: Thumbnail">
        </div>
    </div>
</article>