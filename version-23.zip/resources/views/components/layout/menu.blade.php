<header class="w-100">
    <nav class="container-fluid navbar navbar-dark navbar-expand-lg">
        
        <button class="navbar-toggler m-2" type="button" data-bs-toggle="collapse" data-bs-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="ms-3 collapse navbr-nav navbar-collapse" id="menu">
                <div class="nav-item"><a href="{{ route('acceuil')}}" class="nav-link link-light px-4 py-3 me-2 my-2 @if(request()->routeIS('acceuil')) active @endif">Acceuil</a></div>
                <div class="nav-item"><a href="{{ route('apropos')}}" class="nav-link link-light px-4 py-3 me-2 my-2 @if(request()->routeIS('apropos')) active @endif">Qui sommes-nous ?</a></div>
                <div class="nav-item"><a href="{{ route('metiers')}}" class="nav-link link-light px-4 py-3 me-2 my-2 @if(request()->routeIS('metiers')) active @endif">Metiers numérique</a></div>
                <div class="nav-item"><a href="{{ route('entrepreneurs')}}" class="nav-link link-light px-4 py-3 me-2 my-2  @if(request()->routeIS('entrepreneurs')) active @endif">Entrepreneurs numérique</a></div>
                <div class="nav-item"><a href="{{ route('ecoles')}}" class="nav-link link-light px-4 py-3 me-2 my-2  @if(request()->routeIS('ecoles')) active @endif">Ecoles numérique</a></div>
            
        </div>
    </nav>
</header>
