@props(['gradient' => false, 'titre' => '', 'reduit' => false, 'annonce' => true])
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>DIGITAL WIKI | {{ $titre }}</title>

    <style>
    .bg-primary {
        background-color: #fed1cc !important;
    }

    .border-primary {
        border-color: #fed1cc !important;
    }
      .img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .img-lg {
          font-size: 3.5rem;
        }
      }
        .nav-link.active,
        .nav-link:hover {
            background-color: #fed1cc;
            color: #000000 !important;
        }
        .btn-primary {
            background-color: #fed1cc;
            color: #000000 !important;
            border: 1px solid  #fed1cc;
        }

        .btn-primary:hover,
        .btn-primary:focus,
        .btn-primary:active {
            border:1px solid #fed1cc;
            background-color: #d7ada8;
        }

        .btn-secondary {
            background-color: #7a97ca;
            color: #ffffff !important;
            border: 1px solid  #7a97ca;
        }

        .btn-secondary:hover,
        .btn-secondary:focus,
        .btn-secondary:active {
            border:1px solid #4b5d7d;
            background-color: #4b5d7d;
        }

        .espace .col-lg-4 {
            margin-bottom: 1.5rem;
            text-align: center;
        }
        .espace .col-lg-4 p {
            margin-right: .75rem;
            margin-left: .75rem;
        }

        .featurette-divider {
            margin: 5rem 0; 
        }

        .featurette-heading {
            font-weight: 300;
            line-height: 1;
            letter-spacing: -.05rem;
        }

    </style>
</head>
<body class="h-100" @if ($gradient) style="background: linear-gradient(to right, blue, pink);" @endif>
    <x-layout.header :reduit="$reduit"></x-layout.header>
    <main class="container-fluid">
        <article class="row">
            @if ($annonce)
                <section class="col-12 col-md-8 ">
                    <!-- Le contenu -->
                    {{ $slot }}
                </section>
                <section class="col-12 col-md-4 p-3 mt-5">
                    <x-annonce></x-annonce>
                </section>
            @else
                <section class="col-12">
                    <!-- Le contenu -->
                    {{ $slot }}
                </section>
            @endif
        </article>
    </main>
    <x-layout.footer></x-layout.footer>
    <!-- Les script -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    </body>
</html>