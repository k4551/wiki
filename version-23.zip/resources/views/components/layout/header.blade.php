@props(['reduit'=> false])
<!-- L'entete  -->
<section class="navbar navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
        <nav class="row w-100">
            <div class="col-12 col-lg-6 py-3">
                @if ($reduit)
                <a href="{{ route('acceuil')}}" type="button" class="btn btn-outline-light border-0 me-2">
                        <i class="fa-solid fa-arrow-left"></i>
                </a>
                @endif

                <a class="navbar-brand" href="{{ route('acceuil')}}">
                    DIGITAL WIKI BY NUMERIQUE WIKI
                </a>
            </div>
                    
            <div class="col-12 col-lg-6 py-3 d-lg-flex justify-content-end">
                <button type="button" class="btn btn-outline-light me-2">
                    <i class="fa-solid fa-cart-shopping"></i>
                </button>
                @auth
                    <a href="{{ route('profile')}}" type="button" class="btn btn-outline-light me-2">
                        <i class="fa-solid fa-user"></i>
                    </a>
                    <form class="d-inline" action="{{route('se-deconnecter')}}" method="post">
                        @csrf
                        @method('post')
                        <button type="submit" class="btn btn-secondary">Se déconnecter</button>
                    </form>
                @endauth
                @guest
                    <a href="{{route('se-connecter')}}" type="button" class="btn btn-outline-light me-2">Se connecter</a>
                    <a href="{{route('s-inscrire')}}" type="button" class="btn btn-secondary">S'inscrire</a>
                @endguest
            </div>

        </nav>
    </div>
    @if (!$reduit)
        <x-layout.menu></x-layout.menu>
    @endif
</section>
