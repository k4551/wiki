<footer class="bg-dark">
    <div class="container py-5">
        <div class="row">


            <div class="col-12 col-lg-4 col-sm-12 pe-3 py-3">
                <div class="row">
                    <div class="col-12">
                        <img src="{{asset('img/logo.png')}}" alt="logo" width="100px">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mt-2 text-white">
                        <i>DIGITAL WIKI BY NUMERIQUE WIKI &copy;</i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <ul class="list-inline mt-4">
                            <li class="list-inline-item"><a href="#" target="_blank" title="twitter">
                                    <i class="fa-brands text-white fa-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="facebook">
                                    <i class="fa-brands text-white fa-facebook-f"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="instagram">
                                    <i class="fa-brands text-white fa-instagram"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="pinterest">
                                    <i class="fa-brands text-white fa-pinterest"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="vimeo">
                                    <i class="fa-brands text-white fa-vimeo"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
    
    
            <div class="col-12 col-lg-4 col-sm-12  pe-3 py-3">
                <h5 class="mb-3 text-white" >DIGITAL WIKI</h5>
    
                <ul class="nav me-auto flex flex-column">
                    <li class="nav-item"><a href="#" class="nav-link link-light py-1">Qui somme nous ?</a></li>
                    <li class="nav-item"><a href="#" class="nav-link link-light py-1">S'incrire</a></li>
                    <li class="nav-item"><a href="#" class="nav-link link-light py-1">Se connecter</a></li>
                </ul>
            </div>
    
    
            <!-- -->
            <div class="col-12 col-lg-4 col-sm-12  pe-3 py-2">
                <div class="row">
                    <div class="col-12 text-white">
                        NEWSLETTER
                    </div>
                    <div class="col-12 text-white">
                        <p>Abonnez-vous à notre newsletter pour recevoir des promotions ou l'actualité du site</p>
                    </div>
                    <div class="col-12">
                        <form action="">
                            <input class="form-control" type="text" placeholder="Entrer votre email">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

