<x-layout.layout :titre="'acheteur'" :annonce="false" :reduit="true">
    <section class="container py-5">
        <div class="py-5 text-center">
            <img class="d-block mx-auto mb-4" src="{{ asset('img/logo.png')}}" alt="" width="72" height="72">
            <h2>Achat</h2>
            <p class="lead px-sm-5">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                Sit, iusto. Placeat doloremque sed facere nisi laborum
                ratione eius ipsa itaque repellendus expedita, iure accusantium
                earum laboriosam cupiditate perferendis. Ipsa, possimus!
            </p>
        </div>
        
        <div class="row g-5">
            <div class="col-md-6 order-md-last">
                <h4 class="d-flex justify-content-between align-items-center mb-3">
                    <span>Votre panier</span>
                    <span class="badge bg-primary rounded-pill">3</span>
                </h4>
                <ul class="list-group mb-3">
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0">Product name</h6>
                            <small class="text-muted">Brief description</small>
                        </div>
                        <span class="text-muted">$12</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span>Total (USD)</span>
                        <strong>$20</strong>
                    </li>
                </ul>
            </div>
            <div class="col-md-6">
                <h4 class="mb-3">Information d'acheteur</h4>
                <form>
                    <div class="input-group form-group my-4">
                        <div class="input-group-text bg-primary"><i class="fas fa-building"></i></div>
                        <input type="text" name="entreprise"  value="{{ old('entreprise') }}" class="form-control" placeholder="votre entreprise">
                    </div>
                    <div class="input-group form-group my-4">
                        <div class="input-group-text bg-primary"><i class="fas fa-envelope"></i></div>
                        <input type="email" name="email"  value="{{ old('email') }}" class="form-control" placeholder="contact@votre-entreprise.com">
                    </div>
                    <div class="input-group form-group my-4">
                        <div class="input-group-text bg-primary"><i class="fas fa-phone"></i></div>
                        <input type="tel" name="contact"  value="{{ old('contact') }}" class="form-control" placeholder="06 123 456 789">
                    </div>
                    <button class="w-100 btn btn-primary btn-lg" type="submit">Continuer</button>
                </form>
            </div>
        </div>
    </section>
</x-layout.layout>