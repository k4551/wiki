<x-layout.layout :titre="'Acceuil'">
    <x-layout.header></x-layout.header>
    <main>
        
    </main>
    <x-layout.footer></x-layout.footer>
</x-layout.layout>