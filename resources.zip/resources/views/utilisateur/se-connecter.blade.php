<x-layout.layout :titre="'Se connecter'">
    <x-layout.header></x-layout.header>
    <main class="container-fluid py-5" style="background: linear-gradient(to right, blue, pink);">
        <div class="row d-flex justify-content-center">
            <div class="col-1 d-flex justify-content-center flex-lg-column">
                <a href="" class="btn btn-outlined my-1" style=" color: #FED1CC"><i class="fs-2 fab fa-facebook-square"></i></a>
                <a href="" class="btn btn-outlined my-1" style=" color: #FED1CC"><i class="fs-2 fab fa-google-plus-square"></i></a>
                <a href="" class="btn btn-outlined my-1" style=" color: #FED1CC"><i class="fs-2 fab fa-twitter-square"></i></a>
            </div>
            <div class="col-12 col-lg-5">
                <div class="card text-white" style="background: rgba(0,0,0,0.5)">
                    <div class="card-header text-center">
                        <h3 class="h3">Se connecter</h3>
                    </div>
                    <div class="card-body">
                        <!-- marge pour affincher des erreurs du validation -->
                        @if ($errors->any())
                            <div class="alert alert-danger" role="alert">
        
                                @foreach ($errors->all() as $error)
                                    <div>{{$error}}</div>
                                @endforeach
                            </div>
                        @endif
        
                        <!-- Form pour se connecter -->
                        <form action="{{ route('se-connecter')}}" method="post">
                            @csrf
                            @method('post')
                            <div class="input-group form-group my-2">
                                <div class="input-group-text" style="background-color: pink;"><i class="fas fa-user"></i></div>
                                <input type="text" name="pseudo"  value="{{ old('pseudo') }}" class="form-control" placeholder="Pseudo">
                            </div>
                            <div class="input-group my-2">
                                <div class="input-group-text" style="background-color: pink;"><i class="fas fa-key"></i></div>
                                <input type="password" name="password" class="form-control" placeholder="Mot de passe">
                            </div>
                            <div class="form-check my-2 ms-1 py-2">
                                <input class="form-check-input" type="checkbox" value="" id="remember">
                                <label class="form-check-label" for="remember">
                                  Se souvenir de moi
                                </label>
                            </div>
                            <div class="form-group float-end">
                                <button type="submit" class="btn btn-primary">Se connecter</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer">
                        <p class="lead text-center">
                            Vous n'etes pas encore inscrit ?
                        </p>
                        <div class="d-flex justify-content-center">
                            <a class="btn btn-link text-decoration-none mx-3 p-2" href="{{ route('s-inscrire')}}">S'inscrire</a>
                            <span class="lead p-1">ou</span>
                            <a class="btn btn-link text-decoration-none mx-3 p-2" href="">Mot de passe oublié</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>
    <x-layout.footer></x-layout.footer>
</x-layout.layout>