
<!-- L'entete  -->
<section class="navbar navbar-dark bg-dark sticky-top">
    <div class="container">
        <nav class="row w-100">
                <div class="col-12 col-lg-6 py-3">
                    <a href="/" class="text-decoration-none">
                        <span class="fs-4 text-white">DIGITAL WIKI BY NUMERIQUE WIKI</span>
                    </a>
                    
                </div>
                <div class="col-12 col-lg-6 py-3 d-lg-flex justify-content-end">
                    <button type="button" class="btn btn-outline-light me-2">
                        <i class="fa-solid fa-cart-shopping"></i>
                    </button>
                    <a href="{{route('se-connecter')}}" type="button" class="btn btn-outline-light me-2">Se connecter</a>
                    <a href="{{route('s-inscrire')}}" type="button" class="btn btn-secondary">S'inscrire</a>
                </div>
            </div>
        </nav>
    </div>
    
    <header class="mb-4 w-100">
        <nav class="container navbar navbar-dark navbar-expand-lg">
            
            <button class="navbar-toggler m-2" type="button" data-bs-toggle="collapse" data-bs-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbr-nav navbar-collapse" id="menu">
                    <div class="nav-item"><a href="#" class="nav-link link-light p-3 me-2 my-2" aria-current="page">Acceuil</a></div>
                    <div class="nav-item"><a href="#" class="nav-link link-light p-3 me-2 my-2 active">Qui sommes-nous ?</a></div>
                    <div class="nav-item"><a href="#" class="nav-link link-light p-3 me-2 my-2">Metiers numérique</a></div>
                    <div class="nav-item"><a href="#" class="nav-link link-light p-3 me-2 my-2">Entrepreneurs numérique</a></div>
                    <div class="nav-item"><a href="#" class="nav-link link-light p-3 me-2 my-2">Ecoles numérique</a></div>
                
            </div>
        </nav>
    </header>
</section>
