
{{-- @auth
<form action="{{ route('sortir')}}" method="post">
    @csrf
        @method('post')
        <button class="btn login d-block">
            Se déconnecter
        </button>
    </form>
    <a class="m-2" href="{{ route('profile')}}" style="color: #fff;">
        <i class="fa-solid fa-user"></i>
    </a>
@endauth

@guest 
    <a class="btn login d-block" href="{{ route('se-connecter')}}" >
        Se connecter
    </a>
@endguest
<button type="button" class="btn position-relative m-3"  style="color: #fff;">
    <i class="fa-solid fa-cart-shopping"></i>
    @if (session('panier_elements'))
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
        {{ session('panier_elements')}}
        <span class="visually-hidden">nouveau annonce ajouté au panier</span>
        </span>
    @endif
</button> --}}