<x-layout.layout>
    <x-layout.header></x-layout.header>
    

    <section id="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 p-0">
                    <img src="{{asset('img/entrepreneur.jpg')}}" alt="Entrepreneur">
                </div>
            </div>
            <div class="row">
                @foreach ($posts as $post)
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3 my-sm-3 my-xs-3">
                        <div class="card">
                            <img src="{{asset('posts/'. $post->illustration)}}" class="card-img-top metier-img" alt="Développeur web" style="height:100%;width: 100%;">
                            <div class="card-body metier-body">
                                <h4 class="card-title text-center"><a class="menu_metiers" href="{{ route('posts.lire', [$post->id, $post->slug]) }}">{{$post->titre}}</a></h4>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
    <x-layout.footer></x-layout.footer>
</x-layout.layout>