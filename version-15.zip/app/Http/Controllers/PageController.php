<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class PageController extends Controller
{
    public function afficherMetiers(){
        $posts = Post::all()->where('type', 'metiers');
        return view('pages.metiers', ['posts' => $posts]); 
    }
    public function afficherEntrepreneurs(){
        $posts = Post::all()->where('type', 'entrepreneurs');
        return view('pages.metiers', ['posts' => $posts]); 
    }
    public function afficherEcoles(){
        $posts = Post::all()->where('type', 'ecoles');
        return view('pages.metiers', ['posts' => $posts]); 
    }
}
