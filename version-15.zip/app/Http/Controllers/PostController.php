<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Commentaire;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Response;

class PostController extends Controller
{

    public function lire(Post $post){
        return view('posts.lire', ['post' => $post]);
    }

    public function sauvegarder(Request $requete){
        $requete->validate([
            'titre' => ['required', 'string', 'max:255'],
            'contenu' => ['required', 'string', 'min:32'], 
            'type' => ['regex:/^(metiers)$|(entrepreneurs)$|(ecoles)$/'],
            'illustration' => ['required', 'file', 'image']
        ]); 
        $slug = Str::slug($requete->titre, '-');
        $illustration =  $slug . '-'. time() .'.' . $requete->illustration->extension();
        $image = $requete->illustration->storeAs('images', $illustration, 'posts');

        Post::create([
            'slug' => $slug ,
            'titre' => $requete->titre,
            'contenu' => $requete->contenu,
            'illustration' => $image,
            'type' => $requete->type,
            'active' => !is_null($requete->active),
            'user_id' => Auth::user()->id
        ]);

        return redirect()->route('profile');
    }

    public function supprimer(Post $post){
        $post->delete();
        return redirect()->route('profile');
    }
    public function commenter(Request $requete, Post $post){
        $requete->validate([ 'contenu' => ['required', 'string', 'max:255']]); 

        Commentaire::create([
            'contenu' => $requete->contenu ,
            'user_id' => Auth::user()->id,
            'post_id' => $post->id
        ]);
        return redirect()->route('posts.lire', [$post->id, $post->slug]);
    }
}
