<x-layout.layout>
    <x-layout.header></x-layout.header>
    <form action="{{ route('posts.sauvegarder')}}" method="post" enctype="multipart/form-data">
        @csrf
        @method('post')
        <div class="countainer m-5">
            <div class="row mt-5">
                <div class="col">
                    <!-- marge pour afficher les erreurs du validation -->
                    @if ($errors->any())
                        <div class="alert alert-danger" role="alert">
        
                            @foreach ($errors->all() as $error)
                                <div>{{$error}}</div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-6">
                    <div class="form-group">
                        <label  class="form-label" for="titre">Titre</label>
                        <input  class="form-control" type="text" id="titre" name="titre"  value="{{ old('titre') }}" placeholder="Titre">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="contenu">Contenu</label>
                        <textarea class="form-control" rows="6" id="contenu" name="contenu" placeholder="Contenu">{{ old('contenu') }}</textarea>
                    </div>
                </div>
                <div class="col-md-6  p-2">
                    <div class="mb-3">
                        <label for="illustration" class="form-label">Illustration</label>
                        <input class="form-control" type="file" accept="image/*" name="illustration" id="illustration">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="type">Type</label>
                        <select class="form-select" id="type" name="type" value="{{ old('type') }}" aria-label="selectionner le type post">
                            <option selected value="metiers">Métiers du numérique</option>
                            <option value="entrepreneurs">Entrepreneurs du numérique</option>
                            <option value="ecoles">Ecoles du numérique</option>
                        </select>
                    </div>
                    <div class="row p-2">
                        <div class="col">
                            <div class="form-check form-switch">
                                <label class="form-check-label" for="active">Active</label>
                                <input class="form-check-input" type="checkbox" id="active" name="active"  checked>
                            </div>
                        </div>
                        <div class="col">
                            <input type="submit" value="Publier" class="btn btn-primary float-end">
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </form>  
    </section>
    <x-layout.footer></x-layout.footer>
</x-layout.layout>