<x-layout.layout>
    <x-layout.header></x-layout.header>
    <section class="container">
        <div class="row">
            <div class="col-8">
                <header class="d-flex justify-content-center">
                    <h1 class="titre_dev">{{$post->titre}}</h1>
                </header>
                <img class="w-100" src="{{ asset('posts/'. $post->illustration)}}" alt="" style="height:auto;">
                <p class="py-2 my-5">
                    {{$post->contenu}}
                </p>
            </div>
            <div class="col-4 p-4">
                <h4>Publié par {{$post->user->pseudo}}</h4>
                <p> au {{ $post->created_at}}</p>
            </div>
        </div>
        <div class="row">
            <div class="titre_post">
                <h1>Espace commentaires</h1>
            </div>
            <hr size="1" color="black">	
            <form method="post" action="{{route('posts.commenter', [$post])}}">
                @csrf
                @method('post')
                <label for="message">Commentaire</label><br>
                <textarea id="message" name="contenu" cols="50" rows="7"></textarea><br>
                    
                <input button type="submit" class="btn btn-secondary mb-2" value="Envoyer le commentaire">
        
            </form>
        </div>
        <div class="row">
            @foreach ($post->commentaires as $commentaire)
                <hr size="1" color="black"> 
                <h6>{{ $commentaire->user->pseudo }} </h6>
                <p class="fz-sm">{{ $commentaire->created_at}}</p>
                <p>{{ $commentaire->contenu }}</p>
            @endforeach
        </div>
    </section>

    <x-layout.footer></x-layout.footer>
</x-layout.layout>