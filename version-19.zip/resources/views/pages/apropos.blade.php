<x-layout.layout>
    <x-layout.header></x-layout.header>
    

    <section id="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 p-0">
                    <img src="{{asset('img/nous.jpg')}}" alt="Qui somme nous">
                </div>
            </div>
        </div>
    </section>
    

    <x-layout.footer></x-layout.footer>
</x-layout.layout>