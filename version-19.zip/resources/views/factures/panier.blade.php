<x-layout.layout>
    <x-layout.header></x-layout.header>

    <section class="container m-5">

        <h1> Panier </h1>
        <p>{{ count(session()->get('panier')) }}</p>
    </section>

    <x-layout.footer></x-layout.footer>
</x-layout.layout>