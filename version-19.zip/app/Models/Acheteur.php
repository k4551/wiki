<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Acheteur extends Model
{
    use HasFactory;
    protected $fillable = [
        'entreprise', 'contact', 'email'
    ];

    public function annonce(){
        return $this->hasOne(Annonce::class);
    }
    public function factures(){
        return $this->hasMany(Facture::class);
    }
}
