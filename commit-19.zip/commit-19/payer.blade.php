<x-layout.layout>
    <x-layout.header></x-layout.header>
    <form action="{{ route('factures.payer', [$facture])}}" method="post">
        @csrf
        @method('post')
        <div class="countainer m-5">
            <div class="row mt-5">
                <div class="col">
                    <!-- marge pour afficher les erreurs du validation -->
                    @if ($errors->any())
                        <div class="alert alert-danger" role="alert">
        
                            @foreach ($errors->all() as $error)
                                <div>{{$error}}</div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-6">
                    <h4 class="h4">Résumé</h4>
                    <div class="row">
                        <div class="col">
                            <h6 class="h6">Abonnement</h6> 
                            <span>{{ $facture->abonnement }}</span>
                        </div>
                        <div class="col">
                            <h6 class="h6">Total</h6>
                            <span>
                                {{ $facture->total }}
                            </span> 
                        </div>
                        <div class="col">
                            <h6 class="h6">Type</h6>
                            <span>
                                {{ $facture->annonce->type }}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label  class="form-label" for="entreprise">Entreprise</label>
                        <input  class="form-control" type="text" id="entreprise" name="entreprise"  value="{{ old('entreprise') }}" placeholder="nom d'entreprise">
                    </div>
                    <div class="form-group">
                        <label  class="form-label" for="entreprise">Contact</label>
                        <input  class="form-control" type="tel" id="contact" name="contact"  value="{{ old('contact') }}" placeholder="contact">
                    </div>
                    <div class="form-group">
                        <label  class="form-label" for="email">Email</label>
                        <input  class="form-control" type="email" id="email" name="email"  value="{{ old('email') }}" placeholder="exemple@mail.com">
                    </div>
                    <div class="form-group my-2">
                        <input type="submit" value="Continuer" class="btn btn-primary float-end">
                    </div>
                </div>
            </div>

        </div>
    </form>  
    </section>
    <x-layout.footer></x-layout.footer>
</x-layout.layout>