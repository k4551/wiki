remplacez dans app/Http/Controllers :
1. AcheteurController.php
2. FactureController.php 
et dans resources/views/components/layout
1. header.blade.php 
et dans resources/views/factures
1. payer.blade.php 