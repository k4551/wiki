<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Acheteur;
use App\Models\Annonce;
use App\Models\Facture;

class FactureController extends Controller
{

    public function creer(Facture $facture){
        return view('factures.payer', ['facture' => $facture]);
    }
    public function payer(Request $requete, Facture $facture){

        $requete->validate([
            'entreprise' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'contact' => ['required', 'regex:/(0)[0-9]{9}/']
        ]); 
        $acheteur = Acheteur::create([
            'entreprise' => $requete->entreprise,
            'email' => $requete->email,
            'contact' => $requete->contact
        ]);
        if ($requete->session()->has('panier_elements')){
            $requete->session()->increment('panier_elements');
        }else 
            $requete->session()->put('panier_elements', 1);

        $facture->acheteur_id = $acheteur->id;
        $facture->save();

        return view('factures.panier');
    }
}
