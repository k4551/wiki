<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Acheteur;
use App\Models\Annonce;
use App\Models\Facture;

class AcheteurController extends Controller
{
    public function acheter(Request $requete, Annonce $annonce){

        $requete->validate([
            'lien' => ['required', 'string', 'max:255'],
        ]); 
        $tatal = $requete->abonnement === 'par_an' ?  $annonce->tarif_par_an : $annonce->tarif_par_mois;
        $facture = Facture::create([
            'total' => $tatal,
            'abonnement' => $requete->abonnement,
            'annonce_id' => $annonce->id,
            'acheteur_id' => null
        ]);

        if ($requete->session()->has('panier')){
            $requete->session()->push('panier', $annonce);
        }else {
            session(['panier' => []]);
            $requete->session()->push('panier', $annonce);
        }
        return redirect()->route('factures.creer', ['facture' => $facture]);
    }
    
    public function payer(Request $requete, Facture $facture){

        $requete->validate([
            'entreprise' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'contact' => ['required', 'regex:/(0)[0-9]{9}/']
        ]); 
        $acheteur = Acheteur::create([
            'entreprise' => $requete->entreprise,
            'contact' => $requete->contact,
            'email' => $requete->email
        ]);

        $facture->acheteur_id = $acheteur->id;
        $facture->save();
        // ajouter les details d'annonce
        // $facture->annonce->lien = '';
        // $facture->annonce->image = '';

        return "page de paiment";
    }
}
