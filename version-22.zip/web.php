<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\UtilisateurController;
use App\Http\Controllers\PostController;


/**
 *  Pages
 */
Route::get('/',[PageController::class, 'afficherAcceuil'])->name('acceuil');
Route::get('/qui-sommes-nous',[PageController::class, 'afficherApropos'])->name('apropos');
Route::get('/metiers-du-numerique',[PageController::class, 'afficherMetiers'])->name('metiers');
Route::get('/entrepreneurs-du-numerique',[PageController::class, 'afficherEntrepreneurs'])->name('entrepreneurs');
Route::get('/ecoles-du-numerique',[PageController::class, 'afficherEcoles'])->name('ecoles');


/**
 *  Utilisateur
 */
Route::middleware('guest')->group(function () {

    // Connexion
    Route::get('/se-connecter', function(){
        return view('utilisateur.se-connecter');
    })->name('se-connecter');
    Route::post('/se-connecter',[UtilisateurController::class, 'se_connecter'])
        ->name('nouvelle-connexion');

    /* Inscription */
    Route::get('/s-inscrire', function(){
        return view('utilisateur.s-inscrire');
    })->name('s-inscrire');
    Route::post('/s-inscrire',[UtilisateurController::class, 's_inscrire'])
    ->name('nouveau-utilisateur');
    
    // A FAIRE: recuperer-md oublier-md confirmer-md
    // A FAIRE: verifier-email
});

Route::middleware('auth')->group(function () {

    // profile d'utilisateur
    Route::get('/profile', function(){
        return view('utilisateur.profile');
    })->name('profile');
    // Se deconnecter
    Route::post('/se-deconnecter', [UtilisateurController::class, 'se_deconnecter'])
    ->name('se-deconnecter');
});



/**
 *  Posts
 */
Route::middleware('auth')->group(function () {
    Route::get('/posts/publier', [PostController::class, 'publier'])->name('posts.publier');
    Route::post('/posts/commentaires/{post}', [PostController::class, 'commenter'])->name('posts.commenter');
    Route::post('/posts/sauvegarder', [PostController::class, 'sauvegarder'])->name('posts.sauvegarder');
    Route::delete('/posts/{post}', [PostController::class, 'supprimer'])->name('posts.supprimer');
});
Route::get('/posts/images/{post}_{slug}', [PostController::class, 'chargerImage'])->name('posts.charger-image');
Route::get('/posts/{post}_{slug}', [PostController::class, 'lire'])->name('posts.lire');
