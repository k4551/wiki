<section id="footer" class="mt-3">

    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 col-sm-12 mt-sm-3 mt-xs-3 text-center">
                <div class="row">
                    <div class="col-12">
                        <img src="{{asset('img/logo_di.png')}}" alt="logo" width="100px">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 mt-2">
                        <i>Digital WIKI by NUMERIQUE WIKI ©</i>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <ul class="list-inline mt-4">
                            <li class="list-inline-item"><a href="#" target="_blank" title="twitter">
                                    <i class="fa-brands fa-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="facebook">
                                    <i class="fa-brands fa-facebook-f"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="instagram">
                                    <i class="fa-brands fa-instagram"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="pinterest">
                                    <i class="fa-brands fa-pinterest"></i></a></li>
                            <li class="list-inline-item"><a href="#" target="_blank" title="vimeo">
                                    <i class="fa-brands fa-vimeo"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-4 col-sm-12 mt-sm-3 mt-xs-3 text-md-left text-sm-center text-xs-center">
                <h5 class="mb-3">Digital WIKI</h5>
                <ul>
                    <li><a href="">FAQ</a></li>
                    <li><a href="">Nous contacter</a></li>
                    <li><a href="{{ route('s-inscrire')}}">S'inscrire</a></li>
                    <li><a href="{{ route('se-connecter')}}">Se connecter</a></li>
                </ul>
            </div>
            <div class="col-12 col-lg-4 col-sm-12 mt-sm-3 mt-xs-3 text-sm-center text-xs-center">
                <div class="row">
                    <div class="col-12">
                        NEWSLETTER
                    </div>
                    <div class="col-12">
                        <p>Abonnez-vous à notre newsletter pour recevoir des promotions ou l'actualité du site</p>
                    </div>
                    <div class="col-12">
                        <form action="">
                            <input class="form-control" type="text" placeholder="Entrer votre email">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
