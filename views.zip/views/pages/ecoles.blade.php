<x-layout.layout>
    <x-layout.header></x-layout.header>


    <section id="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 p-0">
                    <img src="{{asset('img/ecole.jpg')}}" alt="Ecoles">
                </div>
            </div>
        </div>
    </section>


    <x-layout.footer></x-layout.footer>
</x-layout.layout>