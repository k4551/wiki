<x-layout.layout>
    <x-layout.header></x-layout.header>
    
    
    <section id="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 p-0">
                    <img src="{{asset('img/metiers.jpg')}}" alt="Métiers Numériques">
                </div>
            </div>
            <div class="row my-3">
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 my-sm-3 my-xs-3">
                    <div class="card">
                        <img src="{{asset('img/dev_web.jpg')}}" class="card-img-top metier-img" alt="Développeur web" style="height:100%;width: 100%;">
                        <div class="card-body metier-body">
                            <h4 class="card-title text-center"><a class="menu_metiers" href="{{ route('blog', 'titre de post')}}">Développeur web</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 my-sm-3 my-xs-3">
                    <div class="card">
                        <img src="{{asset('img/dev_mobile.jpg')}}" class="card-img-top metier-img" alt="Développeur mobile" >
                        <div class="card-body metier-body">
                            <h4 class="card-title text-center"><a class="menu_metiers" href="{{ route('blog', 'titre de post')}}">Développeur mobile</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 my-sm-3 my-xs-3">
                    <div class="card">
                        <img src="{{asset('img/charge.jpg')}}" class="card-img-top metier-img" alt="Chef de projet digital">
                        <div class="card-body metier-body">
                            <h4 class="card-title text-center"><a class="menu_metiers" href="{{ route('blog', 'titre de post')}}">Chef de projet digital</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 my-sm-3 my-xs-3">
                    <div class="card">
                        <img src="{{asset('img/reseau.jpg')}}" class="card-img-top metier-img" alt="Administrateur systèmes, réseaux et cloud">
                        <div class="card-body metier-body">
                            <h4 class="card-title text-center"><a class="menu_metiers" href="{{ route('blog', 'titre de post')}}">Administrateur systèmes, réseaux et cloud</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <x-layout.footer></x-layout.footer>
</x-layout.layout>