<x-layout.layout>
    <x-layout.header></x-layout.header>
    

<br><br>
	 
	 <div class="titre_dev" style="margin-left:70px;">
	 <h2>Développeur web </h2>
	</div>

<p id="dev_web">
Le développeur web / la développeuse réalise l’ensemble des fonctionnalités techniques d’un site ou d'une application web. <br>Technicien ou ingénieur, il ou elle conçoit des sites sur mesure ou adapte des solutions techniques existantes en fonction du projet et de la demande du client.<br>
Description métier<br><br>
À partir du cahier des charges rédigé par le chef de projet en fonction des désirs du client, le développeur web / la développeuse web analyse les besoins, choisit la solution technique la mieux adaptée et développe les fonctionnalités du site web ou de l'application web. <br>Pour cette dernière étape, il rédige des lignes de code.

Le développeur web peut aussi apporter des solutions aux problèmes présents dans un site déjà en ligne et détectés par le client ou par les internautes. <br>Dans ce cas, le développeur procède au diagnostic et à la mise en ligne des corrections, sans interruption du fonctionnement du site.<br>

Selon les termes du contrat, le développeur effectue parfois la formation du client à la réception du site et/ou suivre, tout au long de la vie du site, le support technique conçu et réalisé par lui.<br> Autrement dit, un développeur mène souvent plusieurs types de réalisations à la fois.<br>

Parallèlement à cette activité principale, le développeur web réalise des notices techniques d’installation et des guides destinés aux utilisateurs.<br>

Pour exercer ce métier, il faut être féru d’informatique et maîtriser les langages de développement web (PHP, SQL, Java, ASP…) ainsi que les CMS (systèmes de gestion de contenu) et autres frameworks.<br>

Le développeur web doit être polyvalent, autonome, respectueux des délais et capable d’intégrer de nouveaux concepts et langages de programmation dans un univers qui évolue très rapidement.
<br>
Le métier peut s'exercer dans une agence web, une SSII (société de services en ingénierie informatique), en tant que salarié ou en indépendant, ou encore directement chez le client.<br> L'armée de terre recrute près de 16 000 postes chaque année y compris pour les fonctions transverses tel que développeur web.<br>

<br><br>
Études / Formation pour devenir Développeur / Développeuse web<br><br>
Les formations débutent au niveau bac + 2.<br> A noter, la nouvelle Ecole 42 à Paris gratuite recrute ses élèves sans diplôme (voir article : Formation développeur à 42 : bienvenue dans la 4e dimension ! ). <br> Vous obtenez à la sortie un certificat <br>
<br><br>
Exemples de formations : 
<br>
niveau bac + 2<br>
BTS SN - systèmes numériques <br>
BTS SIO - services informatiques aux organisations<br>
Titre professionnel architecte intégrateur d'applications web<br><br>
niveau bac + 3<br>
Licence informatique (Besançon, Brest, Paris 6…)<br>
Licence professionnelle métiers de l'informatique : applications web<br>
Différents parcours : développeur full stack (la Rochelle)<br>
Licence professionnelle métiers du design<br>
Différents parcours : activités et techniques de communication <br>
BUT informatique<br>
Titre professionnel concepteur développeur d'application web et mobile<br>
Diplôme (type bachelor) d'école spécialisée : Ecole du multimédia...<br><br>
niveau bac + 5<br>
Master informatique<br>
Différents parcours :  conception et développement de solutions informatiques intégrées (Angers), ingénierie logicielle pour l’internet (Artois, Rennes 1), langages et programmation (Paris Diderot)
Diplôme d'ingénieur (écoles du réseau CS2I, ECE Paris, Epitech, EFREI Villejuif, Ensimag Grenoble, Epsi, Supinfo, Insa…)
Plus de détails sur les masters : www.trouvermonmaster.gouv.fr

 
<br><br>
 

Salaires<br>
Environ 1 900 € brut par mois pour un développeur technicien débutant. Les rémunérations évoluent rapidement avec l'expérience.<br>

Armée de terre : 1 384 € net mensuel (hors primes) pour un célibataire sans charge de famille. Cette rémunération peut-être multipliée jusqu'à 2,5 fois en opération extérieure. 
<br><br>
Evolutions de carrière<br>
Un développeur peut se spécialiser dans un secteur d’activité précis : jeux vidéo, e-marketing, édition en ligne, banque, assurance…
<br>
Avec de l’expérience et du savoir-faire, il peut encadrer une équipe de développeurs ou devenir chef de projet technique.
<br>

Josée Lesparre © CIDJ - 22/02/2022
<br>
Crédit photo : Ilya Pavlov - Unsplash

</p>
<!----------------------------------------------------->



<div class="titre_post" style="margin-left:70px; font-size:50px;">
	<h1>Espace commentaires</h1>
</div>
	
<div class="commentaire" style="margin-left: 70px; margin-right:70px;"> 
	<hr size="1" color="black">	
	<form method="post" action="">
		<label for="pseudo">Pseudo</label><br>
		<input type="text" id="pseudo" name="pseudo" maxlength="20" pattern="[a-zA-Z0-9.-_]+" title="caractère autorisés : a-zA-Z0-9.-_"><br>
			
		<label for="message">Commentaire</label><br>
		<textarea id="message" name="message" cols="50" rows="7"></textarea><br>
			
		<input button type="submit" class="btn btn-secondary mb-2" value="Envoyer le commentaire">

		<hr size="1" color="black"> 
	</form>
</div>
    

<x-layout.footer></x-layout.footer>
</x-layout.layout>
