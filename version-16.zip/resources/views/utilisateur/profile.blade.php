<x-layout.layout>
    <x-layout.header></x-layout.header>

    <section class="container">
        <div class="row py-5">
            <!-- Les info d'utilisateur -->
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                      <h5 class="card-title">{{ Auth::user()->pseudo  }}</h5>
                      <p class="card-text">{{ Auth::user()->prenom ." ". Auth::user()->nom}} </p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">{{ Auth::user()->tel }}</li>
                        <li class="list-group-item">{{ Auth::user()->email }}</li>
                        <li class="list-group-item">{{ Auth::user()->adresse }}</li>
                    </ul>
                    <div class="card-body">
                      <a href="" class="card-link">Modifier</a>
                    </div>
                </div>
            </div>

            <!-- Les posts publié par l'utilisateur -->
            <div class="col-8">
                <div class="m-2">
                    <a href="{{ route('posts.publier')}}" class="btn btn-primary">Publier nouveau post</a>
                </div>
                <ul class="list-group m-2">
                    @foreach (Auth::user()->posts()->get() as $post)
                        <li class="list-group-item d-flex justify-content-between align-items-start">
                            <div class="ms-2 me-auto">
                                <div class="fw-bold">{{ $post->titre}}</div>
                                <p>{{ $post->created_at}}</p>
                                <a href="{{ route('posts.lire', [$post->id, $post->slug]) }}">Lire</a>
                            </div>
                            <div class="">
                                <a href="" class="btn">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form action="{{ route('posts.supprimer', $post->id)}}" method="post">
                                    @csrf
                                    @method('delete')
                                    <button type="submit" class="btn">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </li>
                    @endforeach
                  </ul>
            </div>
        </div>
    </section>

    <x-layout.footer></x-layout.footer>
</x-layout.layout>