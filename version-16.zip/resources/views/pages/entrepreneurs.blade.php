<x-layout.layout>
    <x-layout.header></x-layout.header>
    

    <section id="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 p-0">
                    <img src="{{asset('img/entrepreneur.jpg')}}" alt="Entrepreneur">
                </div>
            </div>
            <div class="row">
                @foreach ($posts as $post)
                    <div class="col-12 col-sm-6 col-md-4 col-lg-3 my-sm-3 my-xs-3">
                        <div class="card">
                            <img src="{{asset('posts/'. $post->illustration)}}" class="card-img-top metier-img" alt="Développeur web" style="height:100%;width: 100%;">
                            <div class="card-body metier-body">
                                <h4 class="card-title text-center"><a class="menu_metiers" href="{{ route('posts.lire', [$post->id, $post->slug]) }}">{{$post->titre}}</a></h4>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>


    <section>
        <div class="container">
            <div class="row">
                <div class="card" style="width: 18rem;">
                    <img src="{{asset('img/placeholder-image.png')}}" class="card-img-top" alt="annonce">
                    <div class="card-body">
                        <p class="card-text">
                            Vous êtes une entrepreneur ou startup , votre pub ici  
                        </p>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('annonces.acheter', $annonce->id)}}" method="post">
                            @csrf 
                            @method('post')
                            <select class="form-select" name="abonnement" aria-label="selectionner l'abonnement">
                                <option value="par_an" selected>€{{$annonce->tarif_par_an}}/an</option>
                                <option value="par_mois">€{{$annonce->tarif_par_mois}}/mois</option>
                            </select>
                            <div class="form-group">
                                <label  class="form-label" for="lien">Lien direct sur votre site</label>
                                <input  class="form-control" type="text" id="lien" name="lien" placeholder="https://www.exemple.com">
                                @error('lien') 
                                    <div class="text-danger"> *{{ $message }} </div>
                                @enderror
                                    
                            </div>
                            <button type="submit" class="btn btn-primary my-2 float-end">Acheter</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <x-layout.footer></x-layout.footer>
</x-layout.layout>