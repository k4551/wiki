
<div class="header">
    <div  class="w-100 position-fixed top-0" style="z-index:24;">
        <div class="title text-center"><h1>Digital WIKI by Numerique WIKI</h1></div>
        <nav class="navbar navbar-expand-lg pb-3">
            <div class="container-fluid">
                <button class="navbar-toggler" style="color: #fed1cc" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon">
                        <i class="fa-solid fa-bars"></i>
                    </span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="{{ route('acceuil')}}">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('apropos')}}">Qui sommes-nous ?</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('metiers')}}">Métiers du numérique</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('entrepreneurs')}}">Entrepreneurs du numérique</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('ecoles')}}">Ecoles du numérique</a>
                        </li>
                    </ul>
                </div>

                @auth
                <form action="{{ route('sortir')}}" method="post">
                    @csrf
                        @method('post')
                        <button class="btn login d-block">
                            Se déconnecter
                        </button>
                    </form>
                    <a class="m-2" href="{{ route('profile')}}" style="color: #fff;">
                        <i class="fa-solid fa-user"></i>
                    </a>
                @endauth
                
                @guest 
                    <a class="btn login d-block" href="{{ route('se-connecter')}}" >
                        Se connecter
                    </a>
                @endguest

                <a href="#" class="m-2" style="color: #fff;">
                    <i class="fa-solid fa-cart-shopping"></i>
                </a>
            </div>
        </nav>
    </div>
    <div style="margin-top:148px"></div>
</div>

