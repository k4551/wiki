<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UtilisateurController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\AnnonceController;
use App\Http\Controllers\AcheteurController;
use App\Http\Controllers\FactureController;

/**
 *  Pages
 */
Route::get('/', function(){ 
        return view('pages.acceuil'); 
    })->name('acceuil');
Route::get('/qui-sommes-nous', function(){ 
        return view('pages.apropos'); 
    })->name('apropos');
Route::get('/metiers-du-numerique',[PageController::class, 'afficherMetiers'])->name('metiers');
Route::get('/entrepreneurs-du-numerique',[PageController::class, 'afficherEntrepreneurs'])->name('entrepreneurs');
Route::get('/ecoles-du-numerique',[PageController::class, 'afficherEcoles'])->name('ecoles');


/**
 *  Blog
 */

Route::middleware('auth')->group(function () {
    Route::get('/posts/publier', function(){
        return view('posts.publier');
    })->name('posts.publier');
    Route::post('/posts/commentaires/{post}', [PostController::class, 'commenter'])->name('posts.commenter');
    Route::post('/posts/sauvegarder', [PostController::class, 'sauvegarder'])->name('posts.sauvegarder');
    Route::delete('/posts/{post}', [PostController::class, 'supprimer'])->name('posts.supprimer');
});
Route::get('/posts/{post}_{slug}', [PostController::class, 'lire'])->name('posts.lire');


/**
 *  Utilisateur
 */

Route::middleware('guest')->group(function () {

    // Connexion
    Route::get('/se-connecter', function(){
        return view('utilisateur.se-connecter');
    })->name('se-connecter');
    Route::post('/se-connecter',[UtilisateurController::class, 'se_connecter'])
        ->name('nouvelle-connexion');

    /* Inscription */
    Route::get('/s-inscrire', function(){
        return view('utilisateur.s-inscrire');
    })->name('s-inscrire');
    Route::post('/s-inscrire',[UtilisateurController::class, 's_inscrire'])
    ->name('nouveau-utilisateur');
    
    // A FAIRE: recuperer-md oublier-md confirmer-md
    // A FAIRE: verifier-email
});
Route::middleware('auth')->group(function () {
    Route::get('/profile', function(){
        return view('utilisateur.profile');
    })->name('profile');
    Route::post('/sortir', [UtilisateurController::class, 'sortir'])
    ->name('sortir');
});

// Annonces
Route::get('/annonces/ajouter',[AnnonceController::class, 'ajouter'])->name('annonces.ajouter');

Route::post('/annonces/{annonce}/acheter',[AcheteurController::class, 'acheter'])->name('annonces.acheter');



Route::get('/factures/{facture}/creer',[FactureController::class, 'creer'])->name('factures.creer');
Route::post('/factures/{facture}',[FactureController::class, 'payer'])->name('factures.payer');


