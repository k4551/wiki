<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Annonce;

class PageController extends Controller
{
    public function afficherMetiers(){
        $posts = Post::all()->where('type', 'metiers');
        $annonce = Annonce::all()->where('type', 'metiers')->first();
        return view('pages.metiers', ['posts' => $posts, 'annonce' => $annonce]); 
    }
    public function afficherEntrepreneurs(){
        $posts = Post::all()->where('type', 'entrepreneurs');
        $annonce = Annonce::all()->where('type', 'entrepreneurs')->first();
        return view('pages.metiers', ['posts' => $posts, 'annonce' => $annonce]); 
    }
    public function afficherEcoles(){
        $posts = Post::all()->where('type', 'ecoles');
        $annonce = Annonce::all()->where('type', 'ecoles')->first();
        return view('pages.metiers', ['posts' => $posts, 'annonce' => $annonce]); 
    }
}
