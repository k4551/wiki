<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Annonce;

class AnnonceController extends Controller
{
    public function ajouter(){

        $annonce = Annonce::create([
            'tarif_par_mois' => 8.99,
            'tarif_par_an' => 86.99,
            'type' => 'metiers',
            'lien' => null,
            'image' => null,
        ]);
        $annonce = Annonce::create([
            'tarif_par_mois' => 4.99,
            'tarif_par_an' => 44.99,
            'type' => 'entrepreneurs',
            'lien' => null,
            'image' => null,
        ]);
        $annonce = Annonce::create([
            'tarif_par_mois' => 6.99,
            'tarif_par_an' => 65.99,
            'type' => 'ecoles',
            'lien' => null,
            'image' => null,
        ]);
        dd('Annonces bien ajoute!');

    }
    
}
