<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Acheteur;
use App\Models\Annonce;
use App\Models\Facture;

class FactureController extends Controller
{

    public function creer(Facture $facture){
        return view('factures.payer', ['facture' => $facture]);
    }
    public function payer(Request $requete, Facture $facture){

        $requete->validate([
            'entreprise' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'contact' => ['required', 'regex:/(0)[0-9]{9}/']
        ]); 
        $acheteur = Acheteur::create([
            'entreprise' => $requete->entreprise,
            'email' => $requete->email,
            'contact' => $requete->contact
        ]);

        $facture->acheteur_id = $acheteur->id;
        $facture->save();
        // ajouter les details d'annonce
        // $facture->annonce->lien = '';
        // $facture->annonce->image = '';

        dd('paiment details');
    }
}
