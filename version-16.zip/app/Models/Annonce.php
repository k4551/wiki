<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Annonce extends Model
{
    use HasFactory;

    protected $fillable = [
        'tarif_par_mois', 'tarif_par_an', 'type', 'lien', 'image'
    ];

    public function acheteur(){
        return $this->belongsTo(Acheteur::class);
    }
    public function facture(){
        return $this->hasMany(Facture::class);
    }

}
