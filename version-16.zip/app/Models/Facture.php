<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Facture extends Model
{
    use HasFactory;
    protected $fillable = [
        'total', 'abonnement', 'payee', 'annonce_id', 'acheteur_id'
    ];

    public function acheteur(){
        return $this->belongsTo(Acheteur::class);
    }

    public function annonce(){
        return $this->belongsTo(Annonce::class);
    }
}
